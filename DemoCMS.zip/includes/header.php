<html>
	<head>
		<title>Sample</title>
		<link href="stylesheets/public.css" media="all" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<div id="header">
			<h1>Sample</h1>
		</div>
		<div id="main">
