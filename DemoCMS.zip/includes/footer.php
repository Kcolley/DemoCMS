		</div>
		<div id="footer">Copyright 2011, Sample Corp</div>
	</body>
</html>
<?php
	// 5. Close connection
	mysql_close($connection);
?>